Basisartikelnr
==============