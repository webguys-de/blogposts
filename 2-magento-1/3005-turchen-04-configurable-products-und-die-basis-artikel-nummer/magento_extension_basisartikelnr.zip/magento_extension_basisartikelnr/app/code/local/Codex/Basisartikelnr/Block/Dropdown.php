<?php

class Codex_Basisartikelnr_Block_Dropdown extends Mage_Core_Block_Template
{

    /**
     * @param null $product
     * @return Mage_Catalog_Model_Product
     */
    public function getProduct($product = null)
    {
        return Mage::registry('current_product');
    }

    public function getOptions($code = null)
    {

        if (!$code) {
            $code = $this->getCode();
            $this->setCode($code);
        }

        $product_collection = $this->getProduct()->getCollection();
        /* @var $product_collection Codex_Basisartikelnr_Model_Productcollection */

        $product_collection->setDisableGroupBy();
        $product_collection->addFieldToFilter('basisartikelnr', $this->getProduct()->getBasisartikelnr());

        $product_collection->addAttributeToSelect($code);

        $values = array();

        foreach ($product_collection AS $product) {
            $values[$product->getData($code)] = array(
                'label' => $product->getData($code . '_value'),
                'url' => $product->getProductUrl(),
            );
        }

        return $values;

    }

    public function isActive($option_id)
    {
        return ($this->getProduct()->getData($this->getCode()) == $option_id);
    }

}