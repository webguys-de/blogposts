<?php

class Codex_Basisartikelnr_Block_Init extends Mage_Core_Block_Template
{

    /**
     * @param null $product
     * @return Mage_Catalog_Model_Product
     */
    protected function getProduct($product = null)
    {
        return Mage::registry('current_product');
    }

    public function getJsonConfig()
    {
        $res = array();

        $codes = explode(',', $this->getCodes());

        $product_collection = $this->getProduct()->getCollection();
        /* @var $product_collection Codex_Basisartikelnr_Model_Productcollection */

        $product_collection->setDisableGroupBy();
        $product_collection->addFieldToFilter('basisartikelnr', $this->getProduct()->getBasisartikelnr());

        foreach ($codes AS $code) {
            $product_collection->addAttributeToSelect($code);
        }

        foreach ($product_collection AS $product) {
            $data = array();
            $data['url'] = $product->getProductUrl();

            foreach ($codes AS $code) {
                $data[$code] = $product->getData($code);
            }

            $res[] = $data;
        }

        return json_encode($res);
    }

}