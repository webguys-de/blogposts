<?php

class Codex_Basisartikelnr_Model_Productcollection extends Mage_Catalog_Model_Resource_Product_Collection
{

    protected $_disabled = false;

    protected function isEnabled()
    {
        return !Mage::app()->getStore()->isAdmin() && !$this->_disabled;
    }

    public function setDisableGroupBy()
    {
        $this->_disabled = true;
    }

    // Basis-Artikel-Nummer läuft nur mit Flat-Tables stabil, also immer aktivieren
    public function isEnabledFlat()
    {
        if (Mage::app()->getStore()->isAdmin()) {
            return false;
        }
        return true;
    }

    protected function _beforeLoad()
    {
        if ($this->isEnabled()) {
            if ($this->isEnabledFlat()) {

                $this->getSelect()->group('basisartikelnr');
                $this->getSelect()->columns(array('basisartikelnr_color_ids' => new Zend_Db_Expr("GROUP_CONCAT(DISTINCT color ORDER BY color_value DESC SEPARATOR ',')")));

            } else {

                $this->joinAttribute('basisartikelnr', 'catalog_product/basisartikelnr', 'entity_id');
                $this->joinAttribute('color', 'catalog_product/color', 'entity_id');

                $this->getSelect()->group('basisartikelnr');
                $this->getSelect()->columns(array('basisartikelnr_color_ids' => new Zend_Db_Expr("GROUP_CONCAT(DISTINCT at_color.value ORDER BY at_color.value DESC SEPARATOR ',')")));

            }

            $this->getSelect()->columns(array('basisartikelnr_count' => new Zend_Db_Expr('COUNT(*)')));
        }
        return parent::_beforeLoad();
    }

    public function getSelectCountSql()
    {
        if ($this->isEnabled()) {
            $this->_renderFilters();

            if ($this->isEnabledFlat()) {
                $countSelect = $this->_getClearSelect()
                    ->columns('COUNT(DISTINCT basisartikelnr) AS cnt')
                    ->resetJoinLeft();
            } else {
                $countSelect = $this->_getClearSelect()
                    ->columns('COUNT(DISTINCT at_basisartikelnr.value) AS cnt')
                    ->resetJoinLeft();
            }

            $countSelect->reset(Zend_Db_Select::GROUP);

            return $countSelect;
        }
        return parent::getSelectCountSql();
    }

}