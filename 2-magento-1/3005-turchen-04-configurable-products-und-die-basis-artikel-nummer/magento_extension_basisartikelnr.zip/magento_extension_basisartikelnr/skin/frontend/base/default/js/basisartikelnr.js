Ajax.Request.prototype.abort = function () {
    this.transport.onreadystatechange = Prototype.emptyFunction;
    this.transport.abort();
    Ajax.activeRequestCount--;
};

Basisartikelnr = Class.create();
Basisartikelnr.prototype = {

    /****************************************************************************** initialize
     *
     */
    initialize:function (config) {

        this.ajax_request = false;
        this.config = config;

        document.observe("dom:loaded", this.dom_loaded.bind(this));
    },

    /****************************************************************************** dom_loaded
     *
     */
    dom_loaded:function () {
        this.dropdowns = $$('select.basisartikelnr').toArray();

        for (var i = 0; i < this.dropdowns.length; i++) {
            Event.observe(this.dropdowns[i], 'change', this.dropdown_changed.bind(this));
        }
    },

    /****************************************************************************** onChange
     *
     */
    dropdown_changed:function (event) {

        element = Event.element(event);

        var reset = false;
        for (var i = 0; i < this.dropdowns.length; i++) {

            if (reset) {
                this.dropdowns[i].value = '';
            }

            if (element.name == this.dropdowns[i].name) {
                reset = true;
            }

        }

        for (var i2 = 0; i2 < this.config.length; i2++) {

            var gefunden = true;
            for (var i = 0; i < this.dropdowns.length && gefunden; i++) {

                var name = this.dropdowns[i].name;
                if (this.dropdowns[i].value != this.config[i2][name]) {
                    gefunden = false;
                }

            }

            if (gefunden) {
                this.showLoading();
                setLocation(this.config[i2]['url'])
            }

        }

    },

    /****************************************************************************** onChange
     *
     */
    showLoading:function () {
    }

}