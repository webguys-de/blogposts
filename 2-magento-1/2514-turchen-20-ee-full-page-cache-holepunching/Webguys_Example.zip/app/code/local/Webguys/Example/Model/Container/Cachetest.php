<?php

class Webguys_Example_Model_Container_Cachetest extends Enterprise_PageCache_Model_Container_Abstract {

	/**
	 * Override method to check if content can be applied without the application initialization
	 */
	/*
	public function applyWithoutApp(&$content)
	{
		$res = parent::applyWithoutApp($content);
		Mage::log(__METHOD__ . " = " . intval($res));
		return $res;
	}
	*/

	/**
	 * Override method to check if content is applied after the application initialization
	 */
	/*
	public function applyInApp(&$content)
	{
		$res = parent::applyInApp($content);
		Mage::log(__METHOD__ . " = " . intval($res));
		return $res;
	}
	*/

	protected function _getIdentifier()
    {
        return $this->_getCookieValue(Enterprise_PageCache_Model_Cookie::COOKIE_CUSTOMER, '');
    }

    protected function _getCacheId()
    {
        return 'EXAMPLE_' . md5($this->_placeholder->getAttribute('cache_id') . ',' . $this->_placeholder->getAttribute('product_id')) . '_' . $this->_getIdentifier();
    }

    protected function _renderBlock()
    {
        $blockClass = $this->_placeholder->getAttribute('block');
        $template = $this->_placeholder->getAttribute('template');

        $block = new $blockClass;
        $block->setTemplate($template)
			->setProductId($this->_placeholder->getAttribute('product_id'));
        return $block->toHtml();
    }
}