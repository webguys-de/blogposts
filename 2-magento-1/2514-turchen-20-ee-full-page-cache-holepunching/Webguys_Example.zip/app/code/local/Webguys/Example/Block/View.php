<?php

class Webguys_Example_Block_View extends Mage_Core_Block_Template
{
	public function getCacheKeyInfo()
	{
		$info = parent::getCacheKeyInfo();
		if (Mage::registry('current_product')) {
			$info['product_id'] = Mage::registry('current_product')->getId();
		}
		return $info;
	}
}