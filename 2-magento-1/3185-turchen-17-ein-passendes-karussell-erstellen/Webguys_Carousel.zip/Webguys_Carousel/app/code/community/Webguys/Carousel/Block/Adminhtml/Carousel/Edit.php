<?php

class Webguys_Carousel_Block_Adminhtml_Carousel_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
                 
        $this->_objectId = 'id';
        $this->_blockGroup = 'carousel';
        $this->_controller = 'adminhtml_carousel';
        
        $this->_updateButton('save', 'label', $this->__('Save Item'));
        $this->_updateButton('delete', 'label', $this->__('Delete Item'));
		
        $this->_addButton('saveandcontinue', array(
            'label'     => $this->__('Save And Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class'     => 'save',
        ), -100);

        $this->_formScripts[] = "
            /*
            function toggleEditor() {
                if (tinyMCE.getInstanceById('carousel_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'carousel_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'carousel_content');
                }
            }
            */
            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    protected function _prepareLayout() {
        parent::_prepareLayout();
        if (Mage::getSingleton('cms/wysiwyg_config')->isEnabled()) {
            $this->getLayout()->getBlock('head')->setCanLoadTinyMce(true);
        }
    }

    public function getHeaderText()
    {
        if( Mage::registry('carousel_data') && Mage::registry('carousel_data')->getId() ) {
            return $this->__("Edit Item '%s'", $this->htmlEscape(Mage::registry('carousel_data')->getTitle()));
        } else {
            return $this->__('Add Item');
        }
    }
}