<?php

class Webguys_Carousel_Block_Carousel extends Mage_Core_Block_Template
{

	public function getCarouselItems() {

        $col = Mage::getModel('carousel/carousel')->getCollection();

        if( (boolean)Mage::getStoreConfig('carousel/settings/show_status') ) {
            $col->addFieldToFilter('status', 1);
        }

        if( (boolean)Mage::getStoreConfig('carousel/settings/show_loggedIn') ) {
            $col->addFieldToFilter('loggedIn', Mage::helper('customer')->isLoggedIn() );
        }

        if( (boolean)Mage::getStoreConfig('carousel/settings/show_store') ) {
            $col->addFieldToFilter('store_id', Mage::app()->getStore()->getId() );
        }

        if( (boolean)Mage::getStoreConfig('carousel/settings/show_sortnr') ) {
            $col->getSelect()->order('sortnr ASC');
        }

		return $col;
	}
	
	public function getImage( $image ) {	
				
		return $this->getUrl( 'media/' ).$image;	
	}
	
}
