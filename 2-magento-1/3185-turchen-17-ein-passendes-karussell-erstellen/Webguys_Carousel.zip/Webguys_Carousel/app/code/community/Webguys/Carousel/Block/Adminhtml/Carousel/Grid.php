<?php

class Webguys_Carousel_Block_Adminhtml_Carousel_Grid extends Mage_Adminhtml_Block_Widget_Grid {

	public function __construct()
	{
		parent::__construct();
		$this->setId('carouselGrid');
		$this->setDefaultSort('sortnr');
		$this->setDefaultDir('ASC');
		$this->setSaveParametersInSession(true);
	}

	protected function _prepareCollection()
	{
		$collection = Mage::getModel('carousel/carousel')->getCollection();
		$this->setCollection($collection);
		return parent::_prepareCollection();
	}

    protected function _prepareColumns()
    {
        if( (boolean)Mage::getStoreConfig('carousel/settings/show_id_in_grid') ) {
            $this->addColumn('carousel_id', array(
                'header'    => $this->__('ID'),
                'align'     =>'right',
                'width'     => '50px',
                'index'     => 'carousel_id',
            ));
        }

        if( (boolean)Mage::getStoreConfig('carousel/settings/show_store') ) {
            $this->addColumn('store_id', array(
                'header'    => $this->__('StoreId'),
                'align'     =>'right',
                'width'     => '50px',
                'index'     => 'store_id',
            ));
        }

        $this->addColumn('title', array(
            'header'    => $this->__('Title'),
            'align'     =>'left',
            'index'     => 'title',
        ));

        if( (boolean)Mage::getStoreConfig('carousel/settings/show_sortnr') ) {
            $this->addColumn('sortnr', array(
                'header'    => $this->__('Sortnr'),
                'align'     =>'left',
                'width'     => '80px',
                'index'     => 'sortnr',
            ));
        }

        if( (boolean)Mage::getStoreConfig('carousel/settings/show_loggedIn') ) {
            $this->addColumn('loggedIn', array(
                'header'    => $this->__('loggedIn'),
                'align'     => 'left',
                'width'     => '80px',
                'index'     => 'loggedIn',
                'type'      => 'options',
                'options'   => array(
                    0 => $this->__('No'),
                    1 => $this->__('Yes'),
                ),
            ));
        }

        if( (boolean)Mage::getStoreConfig('carousel/settings/show_status') ) {
            $this->addColumn('status', array(
                'header'    => $this->__('Status'),
                'align'     => 'left',
                'width'     => '80px',
                'index'     => 'status',
                'type'      => 'options',
                'options'   => array(
                    1 => $this->__('Enabled'),
                    2 => $this->__('Disabled'),
                ),
            ));
        }

        $this->addColumn('action',
            array(
                'header'    =>  $this->__('Action'),
                'width'     => '100',
                'type'      => 'action',
                'getter'    => 'getId',
                'actions'   => array(
                    array(
                        'caption'   => $this->__('Edit'),
                        'url'       => array('base'=> '*/*/edit'),
                        'field'     => 'id'
                    )
                ),
                'filter'    => false,
                'sortable'  => false,
                'index'     => 'stores',
                'is_system' => true,
        ));
		
      return parent::_prepareColumns();
  }

    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('carousel_id');
        $this->getMassactionBlock()->setFormFieldName('carousel');

        $this->getMassactionBlock()->addItem('delete', array(
             'label'    => Mage::helper('carousel')->__('Delete'),
             'url'      => $this->getUrl('*/*/massDelete'),
             'confirm'  => Mage::helper('carousel')->__('Are you sure?')
        ));

        $statuses = Mage::getSingleton('carousel/status')->getOptionArray();

        array_unshift($statuses, array('label'=>'', 'value'=>''));
        $this->getMassactionBlock()->addItem('status', array(
             'label'=> $this->__('Change status'),
             'url'  => $this->getUrl('*/*/massStatus', array('_current'=>true)),
             'additional' => array(
                    'visibility' => array(
                         'name' => 'status',
                         'type' => 'select',
                         'class' => 'required-entry',
                         'label' => $this->__('Status'),
                         'values' => $statuses
                     )
             )
        ));
        return $this;
    }

  public function getRowUrl($row)
  {
      return $this->getUrl('*/*/edit', array('id' => $row->getId()));
  }

}
