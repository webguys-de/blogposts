<?php

class Webguys_Carousel_Block_Adminhtml_Carousel_Edit_Tab_Form
    extends Mage_Adminhtml_Block_Widget_Form
    implements Mage_Adminhtml_Block_Widget_Tab_Interface
{

    public function getTabLabel()
    {
        return $this->__('Content');
    }

    public function getTabTitle()
    {
        return $this->__('Content');
    }

    public function canShowTab()
    {
        return true;
    }

    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $action
     * @return bool
     */
    protected function _isAllowedAction($action)
    {
        return Mage::getSingleton('admin/session')->isAllowed('cms/page/' . $action);
    }

    protected function _prepareForm()
    {
        $form = new Varien_Data_Form();
        $this->setForm($form);
        $fieldset = $form->addFieldset('carousel_form', array('legend'=>Mage::helper('carousel')->__('Allgemein')));

        $fieldset->addField('title', 'text', array(
            'label'     => $this->__('Title'),
            'required'  => false,
            'name'      => 'title',
        ));

        if( (boolean)Mage::getStoreConfig('carousel/settings/show_status') ) {
            $fieldset->addField('status', 'select', array(
                'label'     => $this->__('Status'),
                'name'      => 'status',
                'values'    => array(
                    array(
                        'value'     => 1,
                        'label'     => $this->__('Enabled'),
                    ),
                    array(
                        'value'     => 2,
                        'label'     => $this->__('Disabled'),
                    ),
                ),
            ));
        }

        if( (boolean)Mage::getStoreConfig('carousel/settings/show_loggedIn') ) {
            $fieldset->addField('loggedIn', 'select', array(
                'label'     => $this->__('Show only if Logged-In'),
                'required'  => false,
                'name'      => 'loggedIn',
                'values'      => array(array('value'=>1,'label'=>'Ja'),array('value'=>0,'label'=>'Nein'))
            ));
        }

        if( (boolean)Mage::getStoreConfig('carousel/settings/show_store') ) {
            $stores = array();
            foreach (Mage::app()->getStores(true,true) as $code => $store) {
                if( $store->getId() == 0 ) continue;
                $name     = $code." (" . $store->getName() . ")";
                $stores[] = array(
                    'value' => $store->getId(),
                    'label' => $name
                );
            }
            $fieldset->addField('store_id', 'select', array(
                'label'     => $this->__('Store View'),
                'name'      => 'store_id',
                'values'    => $stores
            ));
        }

        if( (boolean)Mage::getStoreConfig('carousel/settings/show_sortnr') ) {
            $fieldset->addField('sortnr', 'text', array(
                'label'     => $this->__('Position'),
                'required'  => false,
                'name'      => 'sortnr',
            ));
        }

        $fieldset->addField('bildgross', 'image', array(
            'label'     => $this->__('Image'),
            'required'  => false,
            'name'      => 'bildgross',
        ));

        if( (boolean)Mage::getStoreConfig('carousel/settings/show_bildklein') ) {
            $fieldset->addField('bildklein', 'image', array(
                'label'     => $this->__('Small Image'),
                'required'  => false,
                'name'      => 'bildklein',
            ));
        }

        if( (boolean)Mage::getStoreConfig('carousel/settings/show_content') ) {

            $args = array(
                'name'      => 'text',
                'label'     => $this->__('Text'),
                'style'     => 'width:600px; height:250px;',
                'required'  => false
            );

            if( (boolean)Mage::getStoreConfig('carousel/settings/use_html_in_text') ) {
                $wysiwygConfig = Mage::getSingleton('cms/wysiwyg_config')->getConfig(
                    array('tab_id' => $this->getTabId())
                );
                $args['wysiwyg'] = true;
                $args['style']   = 'width:650px; height:350px;';
                $args['config']  = $wysiwygConfig;
            }

            $fieldset->addField('text', 'editor', $args);
        }

        if( (boolean)Mage::getStoreConfig('carousel/settings/show_link') ) {
            $fieldset->addField('link', 'text', array(
                'label'     => $this->__('Link'),
                'required'  => false,
                'name'      => 'link',
            ));
        }

        if( (boolean)Mage::getStoreConfig('carousel/settings/show_link_caption') ) {
            $fieldset->addField('link_caption', 'text', array(
                'label'     => $this->__('Link Caption'),
                'required'  => false,
                'name'      => 'link_caption',
            ));
        }

        if ( Mage::getSingleton('adminhtml/session')->getCarouselData() ) {

          $form->setValues(Mage::getSingleton('adminhtml/session')->getCarouselData());
          Mage::getSingleton('adminhtml/session')->setCarouselData(null);
        } elseif ( Mage::registry('carousel_data') ) {
          $form->setValues(Mage::registry('carousel_data')->getData());
        }
        return parent::_prepareForm();
    }
}
