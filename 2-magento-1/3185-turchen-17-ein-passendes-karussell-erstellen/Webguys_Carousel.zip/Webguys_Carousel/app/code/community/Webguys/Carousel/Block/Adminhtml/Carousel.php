<?php
class Webguys_Carousel_Block_Adminhtml_Carousel extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_carousel';
    $this->_blockGroup = 'carousel';
    $this->_headerText = $this->__('Carousel');
    $this->_addButtonLabel = Mage::helper('carousel')->__('Add');
    parent::__construct();
  }
}
