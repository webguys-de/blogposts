<?php

class Codex_Konfigurator_Helper_Data extends  Mage_Core_Helper_Abstract {

    public function getActiveModulnamesByProduct( Mage_Catalog_Model_Product $product ) {
        return array( 'hallowelt' );
    }

}