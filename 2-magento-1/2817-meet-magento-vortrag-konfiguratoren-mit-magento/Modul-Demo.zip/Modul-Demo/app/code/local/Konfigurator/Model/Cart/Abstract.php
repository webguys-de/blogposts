<?php

class Codex_Konfigurator_Model_Cart_Abstract extends Varien_Object {

    protected $_item;

    protected $_product;
    /* @var $_product Mage_Catalog_Model_Product */

    public function getProduct() {
        if ( $this->_product instanceof Mage_Catalog_Model_Product ) {
            return $this->_product;
        }

        if ( !$this->_product instanceof Mage_Catalog_Model_Product ) {
            $this->_product = Mage::registry('current_product');
        }
        return $this->_product;
    }

    public function setProduct( $product ) {
        $this->_product = $product;
        return $this;
    }

    public function load( $item ) {
        $this->_product = $item->getProduct();
        $this->_item = $item;
        return $this;
    }

    public function save( $item ) {
        return $this;
    }

    public function validate() {
        
    }

}