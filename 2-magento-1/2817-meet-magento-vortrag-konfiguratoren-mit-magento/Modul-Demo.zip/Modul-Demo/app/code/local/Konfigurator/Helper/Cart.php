<?php

class Codex_Konfigurator_Helper_Cart extends  Mage_Core_Helper_Abstract {


}