<?php

$installer = $this;
$installer->startSetup();

$setup = new Mage_Eav_Model_Entity_Setup('core_setup');

foreach( array('hallowelt_text', 'hallowelt_position_x', 'hallowelt_position_y') AS $name ) {

    $installer->getConnection()->addColumn(
         $installer->getTable('sales_flat_quote_item'),
         $name,
        'TEXT NULL DEFAULT NULL'
    );

    $installer->getConnection()->addColumn(
         $installer->getTable('sales_flat_order_item'),
         $name,
        'TEXT NULL DEFAULT NULL'
    );

}

$installer->endSetup();