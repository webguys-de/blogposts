<?php

class Codex_Konfigurator_Block_Abstract extends Mage_Core_Block_Template {

    protected $_modelName = NULL;
    protected $_modelCache = NULL;

    /**
     * @return Mage_Catalog_Model_Product
     */
    public function getProduct() {
        return $this->_getModel()->getProduct();
    }

    /**
     * @return Codex_Konfigurator_Model_Cart_Abstract
     */
    protected function _getModel() {
        if ( !$this->_modelCache ) {
            $this->_modelCache = Mage::getModel('codex_konfigurator/cart_'.$this->_modelName);
            /* @var $result Codex_Konfigurator_Model_Cart_Abstract */

            if ( $item = $this->getQuoteItem() ) {
                $this->_modelCache->load( $item );
            }

        }
        return $this->_modelCache;
    }

    /**
     * Retrieve shopping cart model object
     *
     * @return Mage_Checkout_Model_Cart
     */
    protected function _getCart()
    {
        return Mage::getSingleton('checkout/cart');
    }

    /**
     * @return Mage_Checkout_Model_Quote_Item
     */
    public function getQuoteItem() {
        return Mage::registry('current_quote_item');
    }


}