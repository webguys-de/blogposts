<?php

class Codex_Konfigurator_Model_Cart {

    public function updateItem( &$quote_item ) {

        $product = $quote_item->getProduct();
        /* @var $product Mage_Catalog_Model_Product */

        /**
         * Über eine Unique-ID legt Magento das Produkt nicht doppelt in den Warenkorb
         */
        $quote_item->addOption(new Varien_Object(
                           	array(
                              		'product' => $quote_item->getProduct(),
                               		'code' => 'unique_id',
                               		'value' => uniqid()
                       	         )
                       	));

        $controller = Mage::registry('controller');
        /* @var $controller Mage_Core_Controller_Varien_Front */

        try {

            foreach( Mage::helper('codex_konfigurator')->getActiveModulnamesByProduct( $product ) AS $module_name ) {
                $module_data = $controller->getRequest()->getParam( $module_name, array() );
                $model = Mage::getModel('codex_konfigurator/cart_'.$module_name);
                $model->load( $quote_item );

                $model->setData( $module_data );
                $model->validate();

                $model->save( $quote_item );
            }

        } catch( Codex_Konfigurator_Model_Cart_Exception $e ) {

            Mage::getSingleton('core/session')->addError( $e->getMessage() );
            $controller->setFlag('',Mage_Core_Controller_Varien_Action::FLAG_NO_DISPATCH,true);

            if ( $quote_item->getId() ) {
                $controller->getResponse()->setRedirect( Mage::getUrl('checkout/cart/configure/', array( 'id' => $quote_item->getId() ) ) );
            } else {
                $controller->getResponse()->setRedirect( $product->getProductUrl() );
            }
            $controller->getResponse()->sendResponse();

            $controller->getRequest()->setDispatched( true );
            exit; // Magento ignoriert an dieser Stelle leider das Dispatched-Flag und arbeitet den nächsten Redirect weiter ab

        }

    }

}
