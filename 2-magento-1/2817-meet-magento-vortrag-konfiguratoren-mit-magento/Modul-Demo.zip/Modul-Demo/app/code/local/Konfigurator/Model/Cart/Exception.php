<?php

class Codex_Konfigurator_Model_Cart_Exception extends Mage_Core_Exception {

}