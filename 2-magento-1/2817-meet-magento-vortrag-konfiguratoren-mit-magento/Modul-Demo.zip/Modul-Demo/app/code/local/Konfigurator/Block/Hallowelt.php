<?php

class Codex_Konfigurator_Block_Hallowelt extends Codex_Konfigurator_Block_Abstract {

    protected $_modelName = 'hallowelt';

    public function getPositionX() {
        return $this->_getModel()->getPositionX();
    }

    public function getPositionY() {
        return $this->_getModel()->getPositionY();
    }

    public function getText() {
        return $this->_getModel()->getText();
    }

}