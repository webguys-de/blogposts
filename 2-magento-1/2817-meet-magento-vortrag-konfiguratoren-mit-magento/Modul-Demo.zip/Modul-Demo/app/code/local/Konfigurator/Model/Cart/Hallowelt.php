<?php

class Codex_Konfigurator_Model_Cart_Hallowelt extends Codex_Konfigurator_Model_Cart_Abstract {

    protected $_prefix = 'hallowelt';

    public function load( $item ) {
        parent::load($item);
        $this->setText( $item->getData( $this->_prefix.'_text' ) );
        $this->setPositionX( $item->getData( $this->_prefix.'_position_x' ) );
        $this->setPositionY( $item->getData( $this->_prefix.'_position_y' ) );
        return $this;
    }

    public function save( $item ) {
        parent::save($item);
        $item->setData( $this->_prefix.'_text', $this->getText() );
        $item->setData( $this->_prefix.'_position_x', $this->getPositionX() );
        $item->setData( $this->_prefix.'_position_y', $this->getPositionY() );

        return $this;
    }

    public function validate() {

        if ( !is_numeric( $this->getPositionX() ) ) {
            throw new Codex_Konfigurator_Model_Cart_Exception('Position X muss numerisch sein');
        }

        if ( !is_numeric( $this->getPositionY() ) ) {
            throw new Codex_Konfigurator_Model_Cart_Exception('Position Y muss numerisch sein');
        }

        if ( strlen( $this->getText() ) > 10 ) {
            throw new Codex_Konfigurator_Model_Cart_Exception('Es sind maximal 10 Zeichen Text erlaubt');
        }
    }

}