<?php

class Codex_Konfigurator_Model_Observer {

    protected $_layoutHandlesToAdd = array();

    public function catalog_controller_product_view( $event ) {

        $product = $event->getProduct();
        /* @var $product Mage_Catalog_Model_Product */

        if ( !Mage::registry('current_quote_item') ) {

            $controller = Mage::registry('controller');
            /* @var $controller Mage_Core_Controller_Varien_Front */

            if( $controller->getRequest()->getControllerName() == 'cart' &&
                $controller->getRequest()->getActionName() == 'configure' ) {

                $id = $controller->getRequest()->getParam('id');

                $cart = $this->_getCart();
                if ( $id ) {

                    // Im Bearbeitungs-Modus (Link aus dem Warenkorb)
                    // merken wir uns das aktive Quote-Item global
                    $quoteItem = $cart->getQuote()->getItemById($id);
                    Mage::register('current_quote_item', $quoteItem);

                }

            }

        }

        if ( $product->getId() ) {

            foreach( Mage::helper('codex_konfigurator')->getActiveModulnamesByProduct( $product ) AS $module_name ) {
                $handle = 'codex_konfigurator_'.$module_name;
                $this->_layoutHandlesToAdd[] = $handle;
            }

        }
        
    }

    public function before_load_layout( $event ) {
        if ( count( $this->_layoutHandlesToAdd ) ) {
            $layoutupdate = $event->getEvent()->getLayout()->getUpdate();
            foreach( $this->_layoutHandlesToAdd AS $handle ) {
                $layoutupdate->addHandle( $handle );
            }
        }
    }

    public function checkout_cart_update_item_complete($event) {
        $item = $event->getItem();
         /* @var $item Mage_Sales_Model_Quote_Item */

        Mage::getModel('codex_konfigurator/cart')->updateItem( $item );

        // Leider wird der Event _nach_ dem Speichern geworfen, wir müssen unser
        // Item also noch einmal speichern
        $item->save();
    }

    public function checkout_cart_product_add_after($event) {

        $item = $event->getQuoteItem();
        /* @var $quote_item Mage_Sales_Model_Quote_Item */

        if ( !$item ) {
            return;
        }

        Mage::getModel('codex_konfigurator/cart')->updateItem( $item );

    }

    /**
     * Retrieve shopping cart model object
     *
     * @return Mage_Checkout_Model_Cart
     */
    protected function _getCart()
    {
        return Mage::getSingleton('checkout/cart');
    }

}